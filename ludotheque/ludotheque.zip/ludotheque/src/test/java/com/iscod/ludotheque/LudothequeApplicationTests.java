package com.iscod.ludotheque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LudothequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
